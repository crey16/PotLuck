# HCWK Wizard — project context

Read this first. It is the handoff from the planning session that produced this
folder. Nothing here is aspirational: the decisions below are settled, and the
code that already exists is tested.

## What this is

A poker training web app — Duolingo-style lessons plus GTO-Wizard-style range
charts and math drills — with friends, leaderboards, head-to-head challenges and
an activity feed. Built to be deployed and shared with friends.

It merges two existing things:

1. **StackSchool** (`~/PycharmProjects/PokerDuolingo`) — a working FastAPI +
   Expo React Native app: 15 tables, 30 endpoints, JWT auth, lessons/scenarios/
   progress/streaks/friends. **Do not modify that folder.** It is the reference
   implementation and stays intact.
2. **A poker math trainer** (`reference/poker-math-trainer.html`) — a
   self-contained HTML app with an exact hand evaluator and 10 drill modules.
   Its engine is already ported to TypeScript in `lib/poker/`.

## Settled decisions

| Decision | Choice | Why |
|---|---|---|
| Hosting | **Everything on Vercel** | Vercel added first-class FastAPI support (docs updated 2026-07). One repo, one `git push`, Next.js frontend + Python API as a Vercel Function. |
| Database | **Supabase Postgres** | Managed, has a serverless connection pooler, and gives Realtime + RLS. |
| Auth | **Supabase Auth** (replaces the JWT system) | Free Google/Apple sign-in, magic links, hosted password reset. Removes the biggest friction for friends signing up. |
| Backend language | **Keep Python/FastAPI** | 2,584 lines of working, tested logic. Port, don't rewrite. |
| Frontend | **Fresh Next.js (App Router) web UI** | Range grids and charts need real screen space. The Expo app's *logic* ports; its layouts do not. |
| Sequencing | **Deployable skeleton first** | Auth + DB + one drill on a live Vercel URL before porting the rest. |

## Repo shape to build toward

```
/                        Next.js app (App Router) — deployed to Vercel
  app/                   routes, server components
  components/            UI
  lib/
    poker/               ✅ ALREADY WRITTEN AND TESTED — engine, math, ranges
    supabase/            client/server helpers
  api/                   FastAPI app (Vercel Python Function)
    index.py             must export a FastAPI instance named `app`
  supabase/
    migrations/          ✅ 0001_initial_schema.sql written
  docs/                  ✅ architecture, migration, API surface, roadmap
  reference/             ✅ the original trainer HTML, for behaviour reference
```

Vercel finds the Python entrypoint automatically at `api/index.py` (or set
`tool.vercel.entrypoint` in `pyproject.toml`). Route the frontend to it with a
rewrite of `/api/:path*` in `next.config.js`.

## What is already done (do not redo)

- **`lib/poker/engine.ts`** — card model, 5/6/7-card evaluator, exact equity by
  full runout enumeration, outs vs a known hand, draw outs with no villain, dead
  out detection, draw classification, spot generation.
- **`lib/poker/math.ts`** — pot odds, EV, break-even bluff, MDF, implied odds,
  rule of 2 & 4 with the >8-outs correction.
- **`lib/poker/ranges.ts`** — 8 preflop scenarios as threshold specs, 13×13 grid
  helpers, combo-accurate range percentages.
- **`lib/poker/engine.test.ts`** — 14 tests, all passing. Run them:
  `npx tsx --test lib/poker/engine.test.ts`
- **`supabase/migrations/0001_initial_schema.sql`** — full schema with RLS.

## Poker-math correctness rules

These were learned the hard way. Violating them produces confidently wrong
numbers that look plausible.

1. **One betting convention, everywhere.** `pot` = total pot AFTER villain's bet
   (what you win). `call` = what it costs you. Functions taking `potBefore` say
   so in the name. Mixing these is the #1 source of wrong answers.
2. **Never hand-code out counts.** Always derive them from the evaluator. A
   hand-written "flush draw = 9 outs" is wrong whenever a board-pairing card
   gives villain a full house.
3. **A hand that lives on the board alone is nobody's out.** Four to a flush or
   four to a straight on the board means the fifth card is shared. `drawOuts`
   already checks this; keep the check if you refactor.
4. **The ×4 rule overstates above 8 outs.** It double-counts runouts that hit on
   both cards. 15 outs is 54%, not 60%. Use `ruleOf4Corrected`.
5. **Label and count must agree.** In the beginner drill mode, a spot is only
   dealt if the named draw has exactly the out count `DRAW_OUTS` says it should.
   Never show "open-ended straight draw" next to an answer of 4.
6. **Preflop ranges are approximations and must be labelled as such in the UI.**
   They are solver-shaped reference ranges, not solver output.

## Product rules carried over from StackSchool

- **XP → level:** `level = (xp / 100) + 1`. Denormalised on the profile row.
- **Streaks:** incremented when the user is active on a new day; reset to 1 if a
  day was skipped. Day boundaries are **America/New_York**, not UTC — see
  `backend/app/activity.py` in StackSchool.
- **Daily activity** is an upsert with `ON CONFLICT DO UPDATE` so it is safe to
  call multiple times per request.
- **Recommendations** are deterministic and rule-based, not AI: find the weakest
  skill tag with ≥5 attempts, serve an uncompleted lesson for it, else a scenario
  at a difficulty matched to accuracy (<40% → 1, <75% → 2, else 3).
- **Friends** are stored bidirectionally — two rows per friendship.

## Working agreements

- **Never touch `~/PycharmProjects/PokerDuolingo`.** Read it for reference only.
- Run `npx tsx --test lib/poker/*.test.ts` after any change to `lib/poker`. Those
  tests encode real bugs that were found and fixed; if one fails, the engine is
  wrong, not the test.
- Secrets go in `.env.local` (git-ignored). `SUPABASE_SERVICE_ROLE_KEY` must
  never reach the browser — server-side only.
- RLS is on for every user-scoped table. If a query returns nothing unexpectedly,
  suspect a missing policy before suspecting the query.
- Vercel Python constraints to design around: **no WebSockets**, 10s function
  timeout on the free plan (60s on Pro), 300–800ms cold starts, no background
  workers. Use **Supabase Realtime from the browser** for live leaderboards and
  feeds, and **pg_cron** for scheduled work.

## Getting oriented

Read in this order: `docs/01-architecture.md` → `docs/02-migration-from-stackschool.md`
→ `docs/03-api-surface.md` → `docs/04-roadmap.md`.
